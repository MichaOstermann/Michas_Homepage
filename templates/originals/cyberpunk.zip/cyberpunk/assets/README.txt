Drop your hero background video here as `hero.webm` (preferred) and optionally `hero.mp4`.
Requirements:
- Duration: short seamless loop (5–15s)
- Resolution: 1920x1080 (or 1280x720 for smaller size)
- Encoding: VP9/AV1 (webm) + H.264 (mp4), muted, no audio track
- Size budget: keep < 4–8 MB for fast loads
The page auto-falls back to the particles canvas if video cannot play.