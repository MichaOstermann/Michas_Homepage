// ═══════════════════════════════════════════════════════════
// HAUNTED MANSION - INTERACTIVE HORROR EFFECTS
// © 2025 Michael Ostermann
// 3D-Effekte, Geisterbahn-Animationen, Interaktive Horror-Elemente
// ═══════════════════════════════════════════════════════════

// JS Copyright Marker
console.log('%c© 2025 Michael Ostermann - Haunted Mansion Template', 'color: #8B0000; font-size: 14px; font-weight: bold;');

// ═══════════════════════════════════════════════════════════
// INIT - Document Ready
// ═══════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
    initFloatingGhosts();
    initFlyingBats();
    initEnterButton();
    initMirrorEffect();
    initParallaxScroll();
    initRoomCards();
    initSpiritsCarousel();
    initCursorEffect();
    initScreamEffect();
    initHouseMouseFollow();
    
    // CMS & Protection
    if (typeof initInlineCMS === 'function') initInlineCMS();
    if (typeof initCopyrightProtection === 'function') initCopyrightProtection();
});

// ═══════════════════════════════════════════════════════════
// FLOATING GHOSTS - Schwebende Geister generieren
// ═══════════════════════════════════════════════════════════

function initFloatingGhosts() {
    const container = document.getElementById('ghostsContainer');
    if (!container) return;
    
    const ghostEmojis = ['👻', '💀', '🧟', '👹', '😈'];
    const ghostCount = 8;
    
    for (let i = 0; i < ghostCount; i++) {
        const ghost = document.createElement('div');
        ghost.className = 'ghost';
        ghost.textContent = ghostEmojis[Math.floor(Math.random() * ghostEmojis.length)];
        ghost.style.left = Math.random() * 100 + '%';
        ghost.style.animationDelay = Math.random() * 10 + 's';
        ghost.style.animationDuration = (15 + Math.random() * 10) + 's';
        container.appendChild(ghost);
    }
}

// ═══════════════════════════════════════════════════════════
// FLYING BATS - Fledermäuse auf Canvas
// ═══════════════════════════════════════════════════════════

function initFlyingBats() {
    const canvas = document.getElementById('batsCanvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const bats = [];
    const batCount = 15;
    
    class Bat {
        constructor() {
            this.reset();
        }
        
        reset() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.vx = (Math.random() - 0.5) * 2;
            this.vy = (Math.random() - 0.5) * 2;
            this.size = 20 + Math.random() * 20;
            this.wingPhase = Math.random() * Math.PI * 2;
        }
        
        update() {
            this.x += this.vx;
            this.y += this.vy;
            this.wingPhase += 0.2;
            
            // Wrap around screen
            if (this.x < -50) this.x = canvas.width + 50;
            if (this.x > canvas.width + 50) this.x = -50;
            if (this.y < -50) this.y = canvas.height + 50;
            if (this.y > canvas.height + 50) this.y = -50;
        }
        
        draw() {
            ctx.save();
            ctx.translate(this.x, this.y);
            
            // Body
            ctx.fillStyle = '#000';
            ctx.beginPath();
            ctx.ellipse(0, 0, this.size * 0.3, this.size * 0.4, 0, 0, Math.PI * 2);
            ctx.fill();
            
            // Wings
            const wingSpread = Math.sin(this.wingPhase) * 0.5 + 0.5;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.quadraticCurveTo(
                -this.size * (0.5 + wingSpread * 0.5), -this.size * 0.5,
                -this.size, 0
            );
            ctx.quadraticCurveTo(
                -this.size * (0.5 + wingSpread * 0.3), this.size * 0.3,
                0, 0
            );
            ctx.fill();
            
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.quadraticCurveTo(
                this.size * (0.5 + wingSpread * 0.5), -this.size * 0.5,
                this.size, 0
            );
            ctx.quadraticCurveTo(
                this.size * (0.5 + wingSpread * 0.3), this.size * 0.3,
                0, 0
            );
            ctx.fill();
            
            ctx.restore();
        }
    }
    
    // Create bats
    for (let i = 0; i < batCount; i++) {
        bats.push(new Bat());
    }
    
    // Animate
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        bats.forEach(bat => {
            bat.update();
            bat.draw();
        });
        
        requestAnimationFrame(animate);
    }
    
    animate();
    
    // Resize handler
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// ═══════════════════════════════════════════════════════════
// ENTER BUTTON - Interaktive Tür-Animation
// ═══════════════════════════════════════════════════════════

function initEnterButton() {
    const btn = document.getElementById('enterBtn');
    if (!btn) return;
    
    let clickCount = 0;
    
    btn.addEventListener('click', () => {
        clickCount++;
        
        if (clickCount === 1) {
            btn.textContent = '🚪 BIST DU SICHER?';
            btn.style.background = 'linear-gradient(135deg, #4a0000 0%, #8B0000 100%)';
        } else if (clickCount === 2) {
            btn.textContent = '⚠️ ES GIBT KEIN ZURÜCK!';
            btn.style.background = 'linear-gradient(135deg, #000 0%, #4a0000 100%)';
        } else if (clickCount === 3) {
            // Jumpscare-ähnlicher Effekt
            document.body.style.animation = 'shake 0.5s';
            btn.textContent = '👻 WILLKOMMEN...';
            btn.style.background = 'linear-gradient(135deg, #39FF14 0%, #2D0845 100%)';
            
            // Scroll zum nächsten Bereich
            setTimeout(() => {
                document.querySelector('.warning-section').scrollIntoView({ 
                    behavior: 'smooth' 
                });
            }, 500);
            
            // Reset button
            setTimeout(() => {
                btn.textContent = '🚪 EINTRETEN WENN DU DICH TRAUST';
                btn.style.background = 'linear-gradient(135deg, #8B0000 0%, #4a0000 100%)';
                clickCount = 0;
                document.body.style.animation = '';
            }, 3000);
        }
    });
}

// ═══════════════════════════════════════════════════════════
// MIRROR EFFECT - Interaktiver Spiegel
// ═══════════════════════════════════════════════════════════

function initMirrorEffect() {
    const mirror = document.getElementById('mirrorSurface');
    const reflection = document.getElementById('reflection');
    if (!mirror || !reflection) return;
    
    const scaryFaces = ['👻', '💀', '😈', '👹', '🧟‍♂️', '👺', '🤡'];
    let lookCount = 0;
    
    mirror.addEventListener('click', () => {
        lookCount++;
        
        if (lookCount < 3) {
            // Normaler Blick
            reflection.textContent = scaryFaces[Math.floor(Math.random() * scaryFaces.length)];
            reflection.style.fontSize = '8rem';
            reflection.style.opacity = '0.7';
            reflection.style.animation = 'fadeInScale 0.5s ease-out';
            
            setTimeout(() => {
                reflection.style.opacity = '0';
            }, 2000);
        } else {
            // Jumpsc are nach 3 Klicks
            reflection.textContent = '😱';
            reflection.style.fontSize = '15rem';
            reflection.style.opacity = '1';
            reflection.style.animation = 'jumpscare 0.3s ease-out';
            
            // Shake effect
            mirror.style.animation = 'shake 0.5s';
            
            // Sound effect (optional - kann als Audio hinzugefügt werden)
            console.log('SCREEEAAM!!!');
            
            setTimeout(() => {
                reflection.style.opacity = '0';
                mirror.style.animation = '';
                lookCount = 0;
            }, 1500);
        }
    });
}

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInScale {
        from { transform: scale(0.5); opacity: 0; }
        to { transform: scale(1); opacity: 0.7; }
    }
    @keyframes jumpscare {
        0% { transform: scale(0); opacity: 0; }
        50% { transform: scale(1.5); opacity: 1; }
        100% { transform: scale(1); opacity: 1; }
    }
`;
document.head.appendChild(style);

// ═══════════════════════════════════════════════════════════
// PARALLAX SCROLL - Parallax-Effekt für Sections
// ═══════════════════════════════════════════════════════════

function initParallaxScroll() {
    const parallaxSections = document.querySelectorAll('.parallax-section');
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        
        parallaxSections.forEach(section => {
            const speed = section.dataset.speed || 0.5;
            const yPos = -(scrolled * speed);
            section.style.transform = `translateY(${yPos}px)`;
        });
    });
}

// ═══════════════════════════════════════════════════════════
// ROOM CARDS - 3D Flip Interaktion
// ═══════════════════════════════════════════════════════════

function initRoomCards() {
    const roomCards = document.querySelectorAll('.room-card');
    
    roomCards.forEach(card => {
        card.addEventListener('click', () => {
            // Toggle flip
            const inner = card.querySelector('.room-inner');
            if (inner.style.transform === 'rotateY(180deg)') {
                inner.style.transform = 'rotateY(0deg)';
            } else {
                inner.style.transform = 'rotateY(180deg)';
            }
        });
        
        // 3D Tilt effect on mouse move
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 10;
            const rotateY = (centerX - x) / 10;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
        });
    });
}

// ═══════════════════════════════════════════════════════════
// SPIRITS CAROUSEL - Geister-Karussell Interaktion
// ═══════════════════════════════════════════════════════════

function initSpiritsCarousel() {
    const spiritCards = document.querySelectorAll('.spirit-card');
    
    spiritCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            // Alle anderen leicht dimmen
            spiritCards.forEach(otherCard => {
                if (otherCard !== card) {
                    otherCard.style.opacity = '0.5';
                }
            });
        });
        
        card.addEventListener('mouseleave', () => {
            spiritCards.forEach(otherCard => {
                otherCard.style.opacity = '1';
            });
        });
    });
}

// ═══════════════════════════════════════════════════════════
// CURSOR EFFECT - Gruselige Cursor-Effekte
// ═══════════════════════════════════════════════════════════

function initCursorEffect() {
    const cursor = document.createElement('div');
    cursor.style.cssText = `
        position: fixed;
        width: 30px;
        height: 30px;
        border: 2px solid #8B0000;
        border-radius: 50%;
        pointer-events: none;
        z-index: 9999;
        transition: all 0.1s ease;
        box-shadow: 0 0 20px rgba(139, 0, 0, 0.5);
    `;
    document.body.appendChild(cursor);
    
    document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX - 15 + 'px';
        cursor.style.top = e.clientY - 15 + 'px';
    });
    
    // Cursor ändern bei Hover über interaktive Elemente
    const interactiveElements = document.querySelectorAll('button, a, .room-card, .mirror-surface, .spirit-card');
    
    interactiveElements.forEach(el => {
        el.addEventListener('mouseenter', () => {
            cursor.style.width = '50px';
            cursor.style.height = '50px';
            cursor.style.borderColor = '#39FF14';
            cursor.style.boxShadow = '0 0 30px rgba(57, 255, 20, 0.8)';
        });
        
        el.addEventListener('mouseleave', () => {
            cursor.style.width = '30px';
            cursor.style.height = '30px';
            cursor.style.borderColor = '#8B0000';
            cursor.style.boxShadow = '0 0 20px rgba(139, 0, 0, 0.5)';
        });
    });
}

// ═══════════════════════════════════════════════════════════
// SCREAM EFFECT - Zufälliger Schrei-Effekt (visuell)
// ═══════════════════════════════════════════════════════════

function initScreamEffect() {
    // Zufällig alle 30-60 Sekunden
    setInterval(() => {
        if (Math.random() < 0.3) { // 30% Chance
            const scream = document.createElement('div');
            scream.textContent = '😱';
            scream.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) scale(0);
                font-size: 10rem;
                z-index: 10000;
                pointer-events: none;
                opacity: 0;
                animation: screamAppear 1s ease-out;
            `;
            
            document.body.appendChild(scream);
            
            setTimeout(() => {
                scream.remove();
            }, 1000);
        }
    }, Math.random() * 30000 + 30000); // 30-60 Sekunden
}

// Scream Animation
const screamStyle = document.createElement('style');
screamStyle.textContent = `
    @keyframes screamAppear {
        0% { transform: translate(-50%, -50%) scale(0); opacity: 0; }
        50% { transform: translate(-50%, -50%) scale(1.5); opacity: 1; }
        100% { transform: translate(-50%, -50%) scale(1); opacity: 0; }
    }
`;
document.head.appendChild(screamStyle);

// ═══════════════════════════════════════════════════════════
// HOUSE MOUSE FOLLOW - Haus folgt Maus
// ═══════════════════════════════════════════════════════════

function initHouseMouseFollow() {
    const house = document.querySelector('.haunted-house-3d');
    if (!house) return;
    
    document.addEventListener('mousemove', (e) => {
        const mouseX = e.clientX / window.innerWidth;
        const mouseY = e.clientY / window.innerHeight;
        
        const rotateY = (mouseX - 0.5) * 30; // -15 to 15 deg
        const rotateX = (mouseY - 0.5) * -20; // -10 to 10 deg
        
        house.style.transform = `rotateY(${rotateY}deg) rotateX(${rotateX}deg)`;
    });
}

// ═══════════════════════════════════════════════════════════
// CONSOLE EASTER EGG
// ═══════════════════════════════════════════════════════════

console.log('%c👻 WILLKOMMEN IM HAUNTED MANSION 👻', 'color: #8B0000; font-size: 20px; font-weight: bold; text-shadow: 0 0 10px #8B0000;');
console.log('%cWenn du das liest, bist du mutiger als die meisten...', 'color: #39FF14; font-size: 14px;');
console.log('%cAber sei gewarnt: Die Geister sehen alles. 👀', 'color: #fff; font-size: 12px;');

// JS Copyright Marker END
// © 2025 Michael Ostermann

